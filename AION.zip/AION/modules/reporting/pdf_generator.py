
"""
PDF Report Generator
Creates professional penetration testing reports
Includes MITRE ATT&CK mapping, executive summaries, technical details
Developed by kakashi-kx
Based on industry-standard reporting formats 
"""

import os
from datetime import datetime
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter, A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.pdfgen import canvas
from reportlab.lib.enums import TA_CENTER, TA_LEFT

class PDFReportGenerator:
    """
    Professional PDF report generator with:
    - Executive summary
    - Technical findings
    - MITRE ATT&CK mapping 
    - Risk ratings
    - Remediation advice
    """
    
    def __init__(self, target, findings, include_mitre=True):
        self.target = target
        self.findings = findings
        self.include_mitre = include_mitre
        self.styles = getSampleStyleSheet()
        self.setup_styles()
        
    def setup_styles(self):
        """Create custom styles for the report"""
        self.styles.add(ParagraphStyle(
            name='Title',
            parent=self.styles['Heading1'],
            fontSize=24,
            textColor=colors.HexColor('#00fff9'),
            alignment=TA_CENTER,
            spaceAfter=30
        ))
        
        self.styles.add(ParagraphStyle(
            name='Heading',
            parent=self.styles['Heading2'],
            fontSize=16,
            textColor=colors.HexColor('#ff00c8'),
            spaceAfter=12,
            spaceBefore=20
        ))
        
        self.styles.add(ParagraphStyle(
            name='SubHeading',
            parent=self.styles['Heading3'],
            fontSize=14,
            textColor=colors.HexColor('#00ff9d'),
            spaceAfter=8
        ))
        
        self.styles.add(ParagraphStyle(
            name='Critical',
            parent=self.styles['Normal'],
            textColor=colors.red,
            fontSize=12,
            fontName='Helvetica-Bold'
        ))
        
        self.styles.add(ParagraphStyle(
            name='High',
            parent=self.styles['Normal'],
            textColor=colors.orange,
            fontSize=12,
            fontName='Helvetica-Bold'
        ))
        
        self.styles.add(ParagraphStyle(
            name='Medium',
            parent=self.styles['Normal'],
            textColor=colors.yellow,
            fontSize=12
        ))
        
        self.styles.add(ParagraphStyle(
            name='Low',
            parent=self.styles['Normal'],
            textColor=colors.green,
            fontSize=12
        ))
        
        self.styles.add(ParagraphStyle(
            name='Info',
            parent=self.styles['Normal'],
            textColor=colors.blue,
            fontSize=11
        ))
        
        self.styles.add(ParagraphStyle(
            name='Code',
            parent=self.styles['Code'],
            fontSize=9,
            fontName='Courier',
            backColor=colors.lightgrey
        ))
    
    def generate(self, output_file=None):
        """Generate PDF report"""
        if not output_file:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            output_file = f"reports/aion_report_{timestamp}.pdf"
        
        os.makedirs('reports', exist_ok=True)
        
        doc = SimpleDocTemplate(
            output_file,
            pagesize=letter,
            rightMargin=72,
            leftMargin=72,
            topMargin=72,
            bottomMargin=72
        )
        
        story = []
        
        # Title page
        story.extend(self.create_title_page())
        story.append(PageBreak())
        
        # Executive Summary
        story.extend(self.create_executive_summary())
        story.append(PageBreak())
        
        # Table of Contents
        story.extend(self.create_toc())
        story.append(PageBreak())
        
        # Methodology
        story.extend(self.create_methodology())
        story.append(PageBreak())
        
        # Findings
        for module, findings in self.findings.items():
            story.extend(self.create_module_findings(module, findings))
            story.append(PageBreak())
        
        # MITRE ATT&CK Mapping
        if self.include_mitre:
            story.extend(self.create_mitre_mapping())
            story.append(PageBreak())
        
        # Remediation
        story.extend(self.create_remediation())
        story.append(PageBreak())
        
        # Build PDF
        doc.build(story)
        return output_file
    
    def create_title_page(self):
        """Create title page"""
        elements = []
        
        # Title
        elements.append(Paragraph("⚡ AION Security Assessment Report", self.styles['Title']))
        elements.append(Spacer(1, 0.5*inch))
        
        # Target
        elements.append(Paragraph(f"Target: {self.target}", self.styles['Heading']))
        elements.append(Spacer(1, 0.3*inch))
        
        # Date
        elements.append(Paragraph(f"Date: {datetime.now().strftime('%B %d, %Y')}", self.styles['Normal']))
        elements.append(Spacer(1, 0.3*inch))
        
        # Author
        elements.append(Paragraph("Generated by: kakashi-kx", self.styles['Normal']))
        elements.append(Spacer(1, 2*inch))
        
        # Disclaimer
        disclaimer = """
        <para>
        <b>CONFIDENTIAL</b><br/>
        This report contains confidential information about the security assessment
        performed on the target system. It is intended solely for authorized personnel.
        Unauthorized distribution is prohibited.
        </para>
        """
        elements.append(Paragraph(disclaimer, self.styles['Italic']))
        
        return elements
    
    def create_executive_summary(self):
        """Create executive summary"""
        elements = []
        
        elements.append(Paragraph("Executive Summary", self.styles['Heading']))
        elements.append(Spacer(1, 0.2*inch))
        
        # Summary statistics
        total_vulns = sum(len(f.get('vulnerabilities', [])) for f in self.findings.values())
        critical = sum(1 for f in self.findings.values() 
                      for v in f.get('vulnerabilities', []) 
                      if v.get('severity') == 'Critical')
        high = sum(1 for f in self.findings.values() 
                  for v in f.get('vulnerabilities', []) 
                  if v.get('severity') == 'High')
        medium = sum(1 for f in self.findings.values() 
                    for v in f.get('vulnerabilities', []) 
                    if v.get('severity') == 'Medium')
        low = sum(1 for f in self.findings.values() 
                 for v in f.get('vulnerabilities', []) 
                 if v.get('severity') == 'Low')
        
        summary_text = f"""
        <para>
        A comprehensive security assessment was conducted on {self.target}. 
        The assessment identified <b>{total_vulns}</b> security issues:
        <br/><br/>
        • Critical: {critical}<br/>
        • High: {high}<br/>
        • Medium: {medium}<br/>
        • Low: {low}<br/>
        </para>
        """
        
        elements.append(Paragraph(summary_text, self.styles['Normal']))
        
        return elements
    
    def create_module_findings(self, module, findings):
        """Create findings section for a module"""
        elements = []
        
        module_names = {
            'recon': 'Reconnaissance',
            'network': 'Network Security',
            'web': 'Web Application Security',
            'exploit': 'Exploitation',
            'crypto': 'Cryptography'
        }
        
        module_name = module_names.get(module, module.capitalize())
        elements.append(Paragraph(f"{module_name} Findings", self.styles['Heading']))
        elements.append(Spacer(1, 0.2*inch))
        
        # Create findings table
        data = [['Severity', 'Finding', 'Location', 'Recommendation']]
        
        for vuln in findings.get('vulnerabilities', []):
            data.append([
                vuln.get('severity', 'Info'),
                vuln.get('type', 'Unknown'),
                vuln.get('url', vuln.get('port', 'N/A')),
                vuln.get('recommendation', 'Investigate further')
            ])
        
        if len(data) > 1:
            table = Table(data, colWidths=[0.8*inch, 2.5*inch, 1.5*inch, 2*inch])
            table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#00fff9')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 10),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor('#1a1f1f')),
                ('TEXTCOLOR', (0, 1), (-1, -1), colors.white),
                ('GRID', (0, 0), (-1, -1), 1, colors.grey)
            ]))
            elements.append(table)
        else:
            elements.append(Paragraph("No vulnerabilities found in this module.", self.styles['Normal']))
        
        return elements
    
    def create_mitre_mapping(self):
        """Create MITRE ATT&CK mapping section"""
        elements = []
        
        elements.append(Paragraph("MITRE ATT&CK Mapping", self.styles['Heading']))
        elements.append(Spacer(1, 0.2*inch))
        
        # MITRE mapping table 
        mitre_data = [
            ['Tactic', 'Technique ID', 'Technique Name', 'Finding'],
            ['Reconnaissance', 'T1595', 'Active Scanning', 'Port scanning'],
            ['Reconnaissance', 'T1590', 'Gather Victim Network Info', 'DNS enumeration'],
            ['Initial Access', 'T1190', 'Exploit Public-Facing Application', 'Web vulnerabilities'],
            ['Execution', 'T1059', 'Command and Scripting Interpreter', 'Reverse shells'],
            ['Privilege Escalation', 'T1068', 'Exploitation for Privilege Escalation', 'Local exploits'],
            ['Credential Access', 'T1110', 'Brute Force', 'Password attacks'],
        ]
        
        table = Table(mitre_data, colWidths=[1.2*inch, 1*inch, 2*inch, 2.5*inch])
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#ff00c8')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('GRID', (0, 0), (-1, -1), 1, colors.grey)
        ]))
        
        elements.append(table)
        elements.append(Spacer(1, 0.2*inch))
        
        elements.append(Paragraph(
            "For more information: https://attack.mitre.org/",
            self.styles['Italic']
        ))
        
        return elements
